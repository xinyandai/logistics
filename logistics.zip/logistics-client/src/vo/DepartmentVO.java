package vo;
/**
 * 20151022
 * �û��˺���Ϣ
 * @author ��
 */
public class DepartmentVO {

	public DepartmentVO() {
		// TODO Auto-generated constructor stub
	}

}
