package vo;

public class SalaryVO {

	public SalaryVO() {
		// TODO Auto-generated constructor stub
	}

}
