package vo;
/**
 * Ӫҵ�����ﵥ
 * @author ��
 *
 */
public class OfficeArrivalListVO {

	public OfficeArrivalListVO() {
		// TODO Auto-generated constructor stub
	}

}
