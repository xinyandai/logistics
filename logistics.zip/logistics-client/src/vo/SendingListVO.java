package vo;
/**
 * �ɼ���
 * @author 
 *
 */
public class SendingListVO {

	public SendingListVO() {
		// TODO Auto-generated constructor stub
	}

}
