package vo;

public class GoDownEntryListVO {

	public GoDownEntryListVO() {
		// TODO Auto-generated constructor stub
	}

}
