package vo;

public class ReceiptListVO {

	public ReceiptListVO() {
		// TODO Auto-generated constructor stub
	}

}
