package vo;
/**
 * 20151022
 * Ա����Ϣ
 * @author ��
 */
public class WarehouseVO {

	public WarehouseVO() {
		// TODO Auto-generated constructor stub
	}

}
