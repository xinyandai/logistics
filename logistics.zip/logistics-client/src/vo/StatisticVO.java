package vo;
/**
 * 20151022
 * @author ��
 */
public class StatisticVO {

	public StatisticVO() {
		// TODO Auto-generated constructor stub
	}

}
