package vo;

public class TranCenterLoadingListVO {

	public TranCenterLoadingListVO() {
		// TODO Auto-generated constructor stub
	}

}
