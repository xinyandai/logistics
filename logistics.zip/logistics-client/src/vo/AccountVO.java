package vo;

public class AccountVO {

	public AccountVO() {
		// TODO Auto-generated constructor stub
	}

}
