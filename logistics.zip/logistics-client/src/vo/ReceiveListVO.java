package vo;

public class ReceiveListVO {

	public ReceiveListVO() {
		// TODO Auto-generated constructor stub
	}

}
