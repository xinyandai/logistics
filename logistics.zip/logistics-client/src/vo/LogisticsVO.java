package vo;

public class LogisticsVO {

	public LogisticsVO() {
		// TODO Auto-generated constructor stub
	}

}
