package vo;

public class CostListVO {

	public CostListVO() {
		// TODO Auto-generated constructor stub
	}

}
