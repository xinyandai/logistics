package vo;

public class DriverVO {

	public DriverVO() {
		// TODO Auto-generated constructor stub
	}

}
