package vo;

public class TransportListVO {

	public TransportListVO() {
		// TODO Auto-generated constructor stub
	}

}
