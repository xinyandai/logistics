package vo;

public class TranCenterArrivalListVO {

	public TranCenterArrivalListVO() {
		// TODO Auto-generated constructor stub
	}

}
