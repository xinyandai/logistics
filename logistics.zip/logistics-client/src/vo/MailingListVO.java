package vo;

public class MailingListVO {

	public MailingListVO() {
		// TODO Auto-generated constructor stub
	}

}
