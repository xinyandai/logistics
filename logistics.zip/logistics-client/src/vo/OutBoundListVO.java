package vo;

public class OutBoundListVO {

	public OutBoundListVO() {
		// TODO Auto-generated constructor stub
	}

}
