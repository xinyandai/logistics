package vo;

public class CarVO {

	public CarVO() {
		// TODO Auto-generated constructor stub
	}

}
