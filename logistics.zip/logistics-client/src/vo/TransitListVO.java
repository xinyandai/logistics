package vo;

public class TransitListVO {

	public TransitListVO() {
		// TODO Auto-generated constructor stub
	}

}
