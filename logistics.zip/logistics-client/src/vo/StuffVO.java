package vo;
/**
 * 20151022
 * Ա����Ϣ
 * @author ��
 */
public class StuffVO {

	public StuffVO() {
		// TODO Auto-generated constructor stub
	}

}
