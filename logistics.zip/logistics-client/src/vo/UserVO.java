package vo;

public class UserVO {

	public UserVO() {
		// TODO Auto-generated constructor stub
	}

}
