package vo;

public class OfficeLoadingListVO {

	public OfficeLoadingListVO() {
		// TODO Auto-generated constructor stub
	}

}
