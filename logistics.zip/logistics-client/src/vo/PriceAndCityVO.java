package vo;

public class PriceAndCityVO {

	public PriceAndCityVO() {
		// TODO Auto-generated constructor stub
	}

}
