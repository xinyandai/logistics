package main;

import presentation.mainui.LoginUI;

public class Main {

	public static void main(String[] args) {
		new LoginUI();

	}

}
