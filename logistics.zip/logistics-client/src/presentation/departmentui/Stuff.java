package presentation.departmentui;

public class Stuff {

	public Stuff() {
		// Ա��
	}

}
