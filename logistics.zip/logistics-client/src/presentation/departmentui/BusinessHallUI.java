package presentation.departmentui;

public class BusinessHallUI {
	//Ӫҵ��

}
