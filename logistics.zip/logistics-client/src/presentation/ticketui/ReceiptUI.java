package presentation.ticketui;

public class ReceiptUI {
//�տ
}
