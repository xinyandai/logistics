package po;
/**
 * 20151022
 * Ա����Ϣ
 * @author ��
 */
public class StuffPO {

	public StuffPO() {
		// TODO Auto-generated constructor stub
	}

}
