package po;

public class ReceiveListPO {

	public ReceiveListPO() {
		// TODO Auto-generated constructor stub
	}

}
