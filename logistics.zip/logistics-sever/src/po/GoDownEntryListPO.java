package po;

public class GoDownEntryListPO {

	public GoDownEntryListPO() {
		// TODO Auto-generated constructor stub
	}

}
