package po;

public class AccountPO {

	public AccountPO() {
		// TODO Auto-generated constructor stub
	}

}
