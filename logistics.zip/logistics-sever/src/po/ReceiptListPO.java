package po;

public class ReceiptListPO {

	public ReceiptListPO() {
		// TODO Auto-generated constructor stub
	}

}
