package po;

public class OfficeLoadingListPO {

	public OfficeLoadingListPO() {
		// TODO Auto-generated constructor stub
	}

}
