package po;

public class LogisticsPO {

	public LogisticsPO() {
		// TODO Auto-generated constructor stub
	}

}
