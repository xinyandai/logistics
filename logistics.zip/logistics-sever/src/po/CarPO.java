package po;

public class CarPO {

	public CarPO() {
		// TODO Auto-generated constructor stub
	}

}
