package po;

public class TranCenterArrivalListPO {

	public TranCenterArrivalListPO() {
		// TODO Auto-generated constructor stub
	}

}
