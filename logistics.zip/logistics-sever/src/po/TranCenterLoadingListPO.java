package po;

public class TranCenterLoadingListPO {

	public TranCenterLoadingListPO() {
		// TODO Auto-generated constructor stub
	}

}
