package po;

public class MailingListPO {

	public MailingListPO() {
		// TODO Auto-generated constructor stub
	}

}
