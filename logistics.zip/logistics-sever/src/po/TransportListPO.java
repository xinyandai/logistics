package po;

public class TransportListPO {

	public TransportListPO() {
		// TODO Auto-generated constructor stub
	}

}
