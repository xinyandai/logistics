package po;
/**
 * 20151022
 * �û��˺���Ϣ
 * @author ��
 */
public class DepartmentPO {

	public DepartmentPO() {
		// TODO Auto-generated constructor stub
	}

}
