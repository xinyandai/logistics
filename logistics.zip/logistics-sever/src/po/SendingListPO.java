package po;

public class SendingListPO {

	public SendingListPO() {
		// TODO Auto-generated constructor stub
	}

}
