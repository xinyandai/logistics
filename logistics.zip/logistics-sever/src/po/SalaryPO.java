package po;

public class SalaryPO {

	public SalaryPO() {
		// TODO Auto-generated constructor stub
	}

}
