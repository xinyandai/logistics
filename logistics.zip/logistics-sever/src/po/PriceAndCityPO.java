package po;

public class PriceAndCityPO {

	public PriceAndCityPO() {
		// TODO Auto-generated constructor stub
	}

}
