package po;

public class OutBoundListPO {

	public OutBoundListPO() {
		// TODO Auto-generated constructor stub
	}

}
