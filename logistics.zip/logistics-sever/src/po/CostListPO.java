package po;

public class CostListPO {

	public CostListPO() {
		// TODO Auto-generated constructor stub
	}

}
