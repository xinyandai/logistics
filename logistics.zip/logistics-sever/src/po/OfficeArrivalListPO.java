package po;
/**
 * Ӫҵ�����ﵥ
 * @author 
 *
 */
public class OfficeArrivalListPO {

	public OfficeArrivalListPO() {
		// TODO Auto-generated constructor stub
	}

}
